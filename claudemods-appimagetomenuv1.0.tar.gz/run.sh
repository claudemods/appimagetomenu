#!/bin/bash
python appimagetomenu.py
