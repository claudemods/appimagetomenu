import os
import sys
import subprocess
from PyQt6.QtCore import QObject, pyqtSlot

class AppImageHandler(QObject):
    @pyqtSlot(str)
    def add_to_plasma_apps_dir(self, appimage_path):
        # Convert the URL to a file path
        if appimage_path.startswith('file://'):
            appimage_path = appimage_path[7:]

        appimage_name = os.path.basename(appimage_path).replace('.AppImage', '')
        desktop_file_dir = os.path.expanduser('~/.local/share/applications')
        icon_dir = os.path.expanduser('~/.local/share/icons/hicolor/256x256/apps')

        # Create directories if they don't exist
        os.makedirs(desktop_file_dir, exist_ok=True)
        os.makedirs(icon_dir, exist_ok=True)

        # Extract the contents of the AppImage
        try:
            result = subprocess.run([appimage_path, '--appimage-extract'], check=True, capture_output=True, text=True)
            print(result.stdout)
        except subprocess.CalledProcessError as e:
            print(f"Error extracting AppImage: {e.stderr}")
            return

        # Find and move the first image file found
        extracted_icon_path = None
        image_extensions = ('.png', '.jpg', '.jpeg', '.ico', '.svg')
        for root, dirs, files in os.walk('squashfs-root'):
            for file in files:
                if file.lower().endswith(image_extensions):
                    extracted_icon_path = os.path.join(root, file)
                    print(f"Found icon file: {extracted_icon_path}")
                    break
            if extracted_icon_path:
                break

        if extracted_icon_path:
            icon_name = os.path.basename(extracted_icon_path)
            os.rename(extracted_icon_path, os.path.join(icon_dir, icon_name))
        else:
            print("No image file found in the extracted contents.")
            return

        # Create the desktop file
        desktop_file_path = os.path.join(desktop_file_dir, f"{appimage_name}.desktop")
        with open(desktop_file_path, 'w') as f:
            f.write("[Desktop Entry]\n")
            f.write(f"Name={appimage_name}\n")
            f.write(f"Exec={appimage_path}\n")
            f.write(f"Icon={os.path.join(icon_dir, icon_name)}\n")
            f.write("Type=Application\n")
            f.write("Categories=Utility;\n")

        print("AppImage added to Plasma applications directory successfully!")

if __name__ == "__main__":
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtQml import QQmlApplicationEngine

    app = QApplication(sys.argv)
    engine = QQmlApplicationEngine()

    handler = AppImageHandler()
    engine.rootContext().setContextProperty("appImageHandler", handler)

    engine.load(os.path.join(os.path.dirname(__file__), "main.qml"))

    if not engine.rootObjects():
        sys.exit(-1)

    sys.exit(app.exec())
