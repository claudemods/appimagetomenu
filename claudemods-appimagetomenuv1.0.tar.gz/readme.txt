claudemods-appimagetomenu v1.0
28/07/24

step 1
simply extract .zip

step2
make the .sh executable and execute the run.sh
select a appimage and let the application do the rest
your appimage will be in your start menu

all have been tested and converted apps work fine

